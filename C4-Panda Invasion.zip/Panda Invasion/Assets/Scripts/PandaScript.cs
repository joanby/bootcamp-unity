using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PandaScript : MonoBehaviour {

	[Tooltip("Vida del panda")]
	public float health;
	[Tooltip("Velocidad del panda")]
	public float speed;
	
	private Animator animator;
	
	
	//Hashings representando los tres nombres de los triggers del animator del panda
	private int animatorDieTriggerHash = Animator.StringToHash("DieTrigger");
	private int animatorEatTriggerHash = Animator.StringToHash("EatTrigger");
	private int animatorHitTriggerHash = Animator.StringToHash("HitTrigger");



	// Use this for initialization
	void Start () {
		//Obtengo una referencia a la propia componente del panda, de tipo Animator
		animator = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	
	
	private void MoveTowards(Vector3 destination){
	
		//s = v * t
		float step = speed * Time.deltaTime;
		
		this.transform.position = Vector3.MoveTowards(this.transform.position, destination, step);
	
		
	}
	
	
	private void Hit(float damage){
		//Resto el daño de mi vida actual
		this.health -= damage;
		
		if (this.health>0) //estoy vivo aún
		{
			this.animator.SetTrigger(animatorHitTriggerHash);
		} else //this.health<=0 -> estoy muerto 
		{ 
			this.animator.SetTrigger(animatorDieTriggerHash);			
		}
		
	}
	
	private void Eat(){
		this.animator.SetTrigger(animatorEatTriggerHash);
	}
	
	
}
