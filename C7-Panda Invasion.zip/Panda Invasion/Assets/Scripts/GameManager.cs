using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

	//La variable waypoints es una lista que contiene posiciones en el mapa
	//public Vector3[] waypoints;

	public Waypoint firstWaypoint;


}
